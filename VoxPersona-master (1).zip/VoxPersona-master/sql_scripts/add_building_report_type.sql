-- Добавление нескольких связей за один запрос
INSERT INTO "buildings_report_type" ("building_id", "report_type_id")
VALUES 
    (1, 3),
	(2, 3),
	(3, 3),
	(1, 4),
	(2, 4),
	(3, 4),
	(1, 7),
	(2, 7),
    (3, 7),
	(1, 8),
	(2, 8),
	(3, 8);