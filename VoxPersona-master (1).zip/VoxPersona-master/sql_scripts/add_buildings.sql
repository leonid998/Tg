INSERT INTO "buildings" ("building_name")
VALUES 
    ('Отель'),
    ('Ресторан'),
	('Центр здоровья');