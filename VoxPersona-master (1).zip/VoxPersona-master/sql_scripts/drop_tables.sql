-- Удаление таблицы "prompts_buildings"
DROP TABLE IF EXISTS "prompts_buildings";

DROP TABLE IF EXISTS "user_road";

-- Удаление таблицы "audit"
DROP TABLE IF EXISTS "audit";

-- Удаление таблицы "transcription"
DROP TABLE IF EXISTS "transcription";

-- Удаление таблицы "buildings_report_type"
DROP TABLE IF EXISTS "buildings_report_type";

-- Удаление таблицы "report_type"
DROP TABLE IF EXISTS "report_type";

-- Удаление таблицы "scenario"
DROP TABLE IF EXISTS "scenario";

-- Удаление таблицы "employee"
DROP TABLE IF EXISTS "employee";

DROP TABLE IF EXISTS "client";

DROP TABLE IF EXISTS "place_zone";

DROP TABLE IF EXISTS "zone";

-- Удаление таблицы "place"
DROP TABLE IF EXISTS "place";

-- Удаление таблицы "buildings"
DROP TABLE IF EXISTS "buildings";

-- Удаление таблицы "prompts"
DROP TABLE IF EXISTS "prompts";

-- Удаление таблицы "city"
DROP TABLE IF EXISTS "city";