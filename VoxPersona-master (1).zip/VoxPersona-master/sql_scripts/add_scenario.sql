-- Добавление нескольких сценариев за один запрос
INSERT INTO "scenario" ("scenario_name")
VALUES 
    ('Интервью'),
    ('Дизайн');