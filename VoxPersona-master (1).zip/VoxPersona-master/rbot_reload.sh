#!/bin/bash

while true; do
    echo "Запускаю main.py из папки src..."
    python3 src/main.py

    if [ $? -eq 0 ]; then
        echo "Процесс завершился нормально."
        break
    else
        echo "Процесс упал. Перезапускаю через 5 секунд..."
        sleep 5
    fi
done